from flask import *
from keras.models import model_from_json
import tensorflow as tf
from tensorflow.keras.models import model_from_json
import numpy as np
app=Flask(__name__)

@app.route('/')
@app.route('/res',methods=['POST','GET'])
def fun():
	if request.method=="POST":
		op=float(request.form['open'])
		hi=float(request.form['high'])
		low=float(request.form['low'])
		vol=float(request.form['volume'])
		#print(op,hi,low,vol)
		json_file = open(r"modelGG.json", 'r')
		loaded_model_json = json_file.read()
		json_file.close()



		loaded_model = model_from_json(loaded_model_json)

		# load weights into new model
		loaded_model.load_weights(r'modelGG.h5')
		print("Loaded model from disk")



		#features = [Open, High, Low, Adj Close, Volume]

		features = np.array([[op, hi, low, vol]])
		prediction = loaded_model.predict(features)
		# prediction = 123545;

		print(prediction)

		return render_template("index.html",data=prediction[0][0])
	else:
		return render_template("index.html")


if __name__=="__main__":
	app.run(debug=True)

