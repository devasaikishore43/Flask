# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
############stock` price lstm

#r"D:\Pspace\financial_data_2000_2018_cleaned.csv"

import pandas as pd
# import tensorflow.keras1s
data = pd.read_csv(r"D:\Pspace\financial_data_2000_2018_cleaned.csv")

x = data[["open", "high", "low", "volume"]]
y = data["adj_close"]

x = x.to_numpy()
y = y.to_numpy()
y = y.reshape(-1, 1)

from sklearn.model_selection import train_test_split

xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2, random_state=40)

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM
model = Sequential()
model.add(LSTM(128, return_sequences=True, input_shape= (xtrain.shape[1], 1)))
model.add(LSTM(64, return_sequences=False))
model.add(Dense(25))
model.add(Dense(1))
model.summary()

model.compile(optimizer='adam', loss='mean_squared_error')
model.fit(xtrain, ytrain, batch_size=1, epochs=30)

import numpy as np
#features = [Open, High, Low, Adj Close, Volume]

features = np.array([[177.089996, 180.419998, 177.070007, 74919600]])
prediction = model.predict(features)
# prediction = 123545;

print(prediction)